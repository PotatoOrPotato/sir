app.controller('UserDetailController',['$scope','$state','$http','$stateParams','toaster',function () {
    
}])